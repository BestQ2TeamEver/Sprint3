<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* etudiant/bareme.php */
class __TwigTemplate_c1c870c05b9fc7ff3c6c3c9d83c949906a060c74edd189ec7874ad3fe1a479f0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "etudiant/bareme.php"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "etudiant/bareme.php"));

        // line 1
        echo "<html>


    <p> Ici vous pouvez parametrer un bareme !\t </p>
    
   <form method = \"get\" action=\"http://localhost:8000/bareme/verifybareme\">
   \t<div>
   \t\t<p> Pour toutes les intervalles fermante de fin, vous pouvez laisser blanc pour indiquer une valeur supérieure à la borne inférieure. </p>\t
   \t\t<p> Donnez une description à votre barème : </p>
   \t\tNom de votre barème :<input type=\"text\" name=\"nom\"><br>

   \t\t<p> Comment déterminer les points pour la progression? (Niveau final - Initial) : <br></p>
Intervalle pour 1pt: <input type=\"number\" name=\"1param11\" value=\"5\"><input type=\"number\" name=\"1param12\" value=\"10\"><br>
Intervalle pour 2pt: <input type=\"number\" name=\"1param21\" value=\"10\"><input type=\"number\" name=\"1param22\" value=\"20\"><br>
Intervalle pour 3pt: <input type=\"number\" name=\"1param31\" value=\"20\"><input type=\"number\" name=\"1param32\" value=\"30\"><br>
Intervalle pour 4pt: <input type=\"number\" name=\"1param41\" value=\"30\"><input type=\"number\" name=\"1param42\" value=\"40\"><br>
Intervalle pour 5pt: <input type=\"number\" name=\"1param51\" value=\"40\"><input type=\"number\" name=\"1param52\" value=\"50\"><br>
\t\t<br>
\t\t<p> Comment déterminer les points pour le temps d'entrainement (en minutes) ? : <br> </p>
Intervalle pour 1pt: <input type=\"number\" name=\"2param11\" value=\"0\"><input type=\"number\" name=\"2param12\" value=\"60\"><br>
Intervalle pour 2pt: <input type=\"number\" name=\"2param21\" value=\"60\"><input type=\"number\" name=\"2param22\" value=\"150\"><br>
Intervalle pour 3pt: <input type=\"number\" name=\"2param31\" value=\"90\"><input type=\"number\" name=\"2param32\" value=\"30\"><br>
Intervalle pour 4pt: <input type=\"number\" name=\"2param41\" value=\"150\"><input type=\"number\" name=\"2param42\" value=\"180\"><br>
Intervalle pour 5pt: <input type=\"number\" name=\"2param51\" value=\"180\"><input type=\"number\" name=\"2param52\" value=\"\"><br>
<br>
<p> Comment déterminer les points pour le nombre de niveaux acquis? ? : <br> </p>
Intervalle pour 1pt: <input type=\"number\" name=\"3param11\" value=\"0\"><input type=\"number\" name=\"3param12\" value=\"4\"><br>
Intervalle pour 2pt: <input type=\"number\" name=\"3param21\" value=\"4\"><input type=\"number\" name=\"3param22\" value=\"6\"><br>
Intervalle pour 3pt: <input type=\"number\" name=\"3param31\" value=\"6\"><input type=\"number\" name=\"3param32\" value=\"7\"><br>
Intervalle pour 4pt: <input type=\"number\" name=\"3param41\" value=\"8\"><input type=\"number\" name=\"3param42\" value=\"9\"><br>
Intervalle pour 5pt: <input type=\"number\" name=\"3param51\" value=\"10\"><input type=\"number\" name=\"3param52\" value=\"\"><br>
<br><br>
Mettre ce barème en favori? <input type=\"checkbox\" id=\"favori\" name=\"favori\" value=\"favori\">
<input type=\"submit\">
</form>
</div>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "etudiant/bareme.php";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<html>


    <p> Ici vous pouvez parametrer un bareme !\t </p>
    
   <form method = \"get\" action=\"http://localhost:8000/bareme/verifybareme\">
   \t<div>
   \t\t<p> Pour toutes les intervalles fermante de fin, vous pouvez laisser blanc pour indiquer une valeur supérieure à la borne inférieure. </p>\t
   \t\t<p> Donnez une description à votre barème : </p>
   \t\tNom de votre barème :<input type=\"text\" name=\"nom\"><br>

   \t\t<p> Comment déterminer les points pour la progression? (Niveau final - Initial) : <br></p>
Intervalle pour 1pt: <input type=\"number\" name=\"1param11\" value=\"5\"><input type=\"number\" name=\"1param12\" value=\"10\"><br>
Intervalle pour 2pt: <input type=\"number\" name=\"1param21\" value=\"10\"><input type=\"number\" name=\"1param22\" value=\"20\"><br>
Intervalle pour 3pt: <input type=\"number\" name=\"1param31\" value=\"20\"><input type=\"number\" name=\"1param32\" value=\"30\"><br>
Intervalle pour 4pt: <input type=\"number\" name=\"1param41\" value=\"30\"><input type=\"number\" name=\"1param42\" value=\"40\"><br>
Intervalle pour 5pt: <input type=\"number\" name=\"1param51\" value=\"40\"><input type=\"number\" name=\"1param52\" value=\"50\"><br>
\t\t<br>
\t\t<p> Comment déterminer les points pour le temps d'entrainement (en minutes) ? : <br> </p>
Intervalle pour 1pt: <input type=\"number\" name=\"2param11\" value=\"0\"><input type=\"number\" name=\"2param12\" value=\"60\"><br>
Intervalle pour 2pt: <input type=\"number\" name=\"2param21\" value=\"60\"><input type=\"number\" name=\"2param22\" value=\"150\"><br>
Intervalle pour 3pt: <input type=\"number\" name=\"2param31\" value=\"90\"><input type=\"number\" name=\"2param32\" value=\"30\"><br>
Intervalle pour 4pt: <input type=\"number\" name=\"2param41\" value=\"150\"><input type=\"number\" name=\"2param42\" value=\"180\"><br>
Intervalle pour 5pt: <input type=\"number\" name=\"2param51\" value=\"180\"><input type=\"number\" name=\"2param52\" value=\"\"><br>
<br>
<p> Comment déterminer les points pour le nombre de niveaux acquis? ? : <br> </p>
Intervalle pour 1pt: <input type=\"number\" name=\"3param11\" value=\"0\"><input type=\"number\" name=\"3param12\" value=\"4\"><br>
Intervalle pour 2pt: <input type=\"number\" name=\"3param21\" value=\"4\"><input type=\"number\" name=\"3param22\" value=\"6\"><br>
Intervalle pour 3pt: <input type=\"number\" name=\"3param31\" value=\"6\"><input type=\"number\" name=\"3param32\" value=\"7\"><br>
Intervalle pour 4pt: <input type=\"number\" name=\"3param41\" value=\"8\"><input type=\"number\" name=\"3param42\" value=\"9\"><br>
Intervalle pour 5pt: <input type=\"number\" name=\"3param51\" value=\"10\"><input type=\"number\" name=\"3param52\" value=\"\"><br>
<br><br>
Mettre ce barème en favori? <input type=\"checkbox\" id=\"favori\" name=\"favori\" value=\"favori\">
<input type=\"submit\">
</form>
</div>
</html>", "etudiant/bareme.php", "C:\\Users\\Numa mrn\\Desktop\\demoSprint3\\VoltaireQ2Project\\templates\\etudiant\\bareme.php");
    }
}
