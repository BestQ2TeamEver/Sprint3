<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* etudiant/etudiant.html.twig */
class __TwigTemplate_bc1d54e668f78fd96a4a83a58e2411ddd0660e238301e1ff22635140ed40bacc extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "etudiant/etudiant.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "etudiant/etudiant.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "etudiant/etudiant.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Information sur l'étudiant ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 3, $this->source); })()), "nomEtudiant", [], "any", false, false, false, 3), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 3, $this->source); })()), "prenomEtudiant", [], "any", false, false, false, 3), "html", null, true);
        echo "!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
\t<a href = \"http://localhost:8000/etudiant\"> Retourner sur la page d'accueil </a>
\t";
        // line 13
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 14
            echo "\t <h1> Etudiant ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 14, $this->source); })()), "nomEtudiant", [], "any", false, false, false, 14), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 14, $this->source); })()), "prenomEtudiant", [], "any", false, false, false, 14), "html", null, true);
            echo " : </h1>
    <p> L'étudiant ";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 15, $this->source); })()), "nomEtudiant", [], "any", false, false, false, 15), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 15, $this->source); })()), "prenomEtudiant", [], "any", false, false, false, 15), "html", null, true);
            echo " à passé ";
            echo twig_escape_filter($this->env, (isset($context["tps"]) || array_key_exists("tps", $context) ? $context["tps"] : (function () { throw new RuntimeError('Variable "tps" does not exist.', 15, $this->source); })()), "html", null, true);
            echo " sur le site du projet Voltaire, il a eu ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["resultat"]) || array_key_exists("resultat", $context) ? $context["resultat"] : (function () { throw new RuntimeError('Variable "resultat" does not exist.', 15, $this->source); })()), "scoreEvaluationInitiale", [], "any", false, false, false, 15), "html", null, true);
            echo "% à l'examen initial. Il est donc noté avec le bareme \"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["bareme"]) || array_key_exists("bareme", $context) ? $context["bareme"] : (function () { throw new RuntimeError('Variable "bareme" does not exist.', 15, $this->source); })()), "nomBareme", [], "any", false, false, false, 15), "html", null, true);
            echo "\". Sa note globale s'éleve à ";
            echo twig_escape_filter($this->env, (isset($context["notetotale"]) || array_key_exists("notetotale", $context) ? $context["notetotale"] : (function () { throw new RuntimeError('Variable "notetotale" does not exist.', 15, $this->source); })()), "html", null, true);
            echo " avec : <br> <ul> <li> ";
            if ((isset($context["noterResultatFinal"]) || array_key_exists("noterResultatFinal", $context) ? $context["noterResultatFinal"] : (function () { throw new RuntimeError('Variable "noterResultatFinal" does not exist.', 15, $this->source); })())) {
                echo " ";
                echo twig_escape_filter($this->env, (isset($context["pointProgression"]) || array_key_exists("pointProgression", $context) ? $context["pointProgression"] : (function () { throw new RuntimeError('Variable "pointProgression" does not exist.', 15, $this->source); })()), "html", null, true);
                echo " points pour la progression ";
            }
            echo " ";
            if (((isset($context["noterResultatFinal"]) || array_key_exists("noterResultatFinal", $context) ? $context["noterResultatFinal"] : (function () { throw new RuntimeError('Variable "noterResultatFinal" does not exist.', 15, $this->source); })()) == 0)) {
                echo " ";
                echo twig_escape_filter($this->env, (isset($context["pointProgression"]) || array_key_exists("pointProgression", $context) ? $context["pointProgression"] : (function () { throw new RuntimeError('Variable "pointProgression" does not exist.', 15, $this->source); })()), "html", null, true);
                echo " points pour la progression , l'étudiant n'a pas encore passé le test final. ";
            }
            echo "</li> <li> ";
            echo twig_escape_filter($this->env, (isset($context["pointNiveau"]) || array_key_exists("pointNiveau", $context) ? $context["pointNiveau"] : (function () { throw new RuntimeError('Variable "pointNiveau" does not exist.', 15, $this->source); })()), "html", null, true);
            echo " points pour le nombre de niveaux acquis avec ";
            echo twig_escape_filter($this->env, (isset($context["niveauatteint"]) || array_key_exists("niveauatteint", $context) ? $context["niveauatteint"] : (function () { throw new RuntimeError('Variable "niveauatteint" does not exist.', 15, $this->source); })()), "html", null, true);
            echo " niveaux validés</li> <li> ";
            echo twig_escape_filter($this->env, (isset($context["pointUtilisation"]) || array_key_exists("pointUtilisation", $context) ? $context["pointUtilisation"] : (function () { throw new RuntimeError('Variable "pointUtilisation" does not exist.', 15, $this->source); })()), "html", null, true);
            echo " points pour le temps passé sur le site. 
    <br><br>
    Voulez vous noter cet étudiant avec un autre barème? 
    <form action=\"http://localhost:8000/etudiant/changerBareme/";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 18, $this->source); })()), "login", [], "any", false, false, false, 18), "html", null, true);
            echo "\">
  \t\t<select name=\"nomBareme\">
  \t\t\t";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["allbareme"]) || array_key_exists("allbareme", $context) ? $context["allbareme"] : (function () { throw new RuntimeError('Variable "allbareme" does not exist.', 20, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["bareme"]) {
                // line 21
                echo "    \t<option value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bareme"], "nomBareme", [], "any", false, false, false, 21), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["bareme"], "nomBareme", [], "any", false, false, false, 21), "html", null, true);
                echo "</option>
    \t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bareme'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 23
            echo "  \t\t</select>
  \t<br><br>
  \t<input type=\"submit\">
  </form>
  ";
        }
        // line 28
        echo "  ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
            // line 29
            echo "  \t";
            if ((twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 29, $this->source); })()), "Login", [], "any", false, false, false, 29) == twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 29, $this->source); })()), "login", [], "any", false, false, false, 29))) {
                // line 30
                echo "  \t<h1> Etudiant ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 30, $this->source); })()), "nomEtudiant", [], "any", false, false, false, 30), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 30, $this->source); })()), "prenomEtudiant", [], "any", false, false, false, 30), "html", null, true);
                echo " : </h1>
  \t<p> L'étudiant ";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 31, $this->source); })()), "nomEtudiant", [], "any", false, false, false, 31), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 31, $this->source); })()), "prenomEtudiant", [], "any", false, false, false, 31), "html", null, true);
                echo " à passé ";
                echo twig_escape_filter($this->env, (isset($context["tps"]) || array_key_exists("tps", $context) ? $context["tps"] : (function () { throw new RuntimeError('Variable "tps" does not exist.', 31, $this->source); })()), "html", null, true);
                echo " sur le site du projet Voltaire, il a eu ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["resultat"]) || array_key_exists("resultat", $context) ? $context["resultat"] : (function () { throw new RuntimeError('Variable "resultat" does not exist.', 31, $this->source); })()), "scoreEvaluationInitiale", [], "any", false, false, false, 31), "html", null, true);
                echo "% à l'examen initial. Il est donc noté avec le bareme \"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["bareme"]) || array_key_exists("bareme", $context) ? $context["bareme"] : (function () { throw new RuntimeError('Variable "bareme" does not exist.', 31, $this->source); })()), "nomBareme", [], "any", false, false, false, 31), "html", null, true);
                echo "\".<br> <ul> <li> ";
                if ((isset($context["noterResultatFinal"]) || array_key_exists("noterResultatFinal", $context) ? $context["noterResultatFinal"] : (function () { throw new RuntimeError('Variable "noterResultatFinal" does not exist.', 31, $this->source); })())) {
                    echo " L'Etudiant a effectué le test final ";
                }
                echo " ";
                if (((isset($context["noterResultatFinal"]) || array_key_exists("noterResultatFinal", $context) ? $context["noterResultatFinal"] : (function () { throw new RuntimeError('Variable "noterResultatFinal" does not exist.', 31, $this->source); })()) == 0)) {
                    echo " L'étudiant n'a pas encore passé le test final. ";
                }
                echo "</li> <li> L'Etudiant a validé ";
                echo twig_escape_filter($this->env, (isset($context["niveauatteint"]) || array_key_exists("niveauatteint", $context) ? $context["niveauatteint"] : (function () { throw new RuntimeError('Variable "niveauatteint" does not exist.', 31, $this->source); })()), "html", null, true);
                echo " niveaux </li> <li> Il a passé ";
                echo twig_escape_filter($this->env, (isset($context["tps"]) || array_key_exists("tps", $context) ? $context["tps"] : (function () { throw new RuntimeError('Variable "tps" does not exist.', 31, $this->source); })()), "html", null, true);
                echo " sur le site du projet voltaire
  \t<br><br>
  ";
            }
            // line 34
            echo "  ";
            if ((twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 34, $this->source); })()), "Login", [], "any", false, false, false, 34) != twig_get_attribute($this->env, $this->source, (isset($context["etudiant"]) || array_key_exists("etudiant", $context) ? $context["etudiant"] : (function () { throw new RuntimeError('Variable "etudiant" does not exist.', 34, $this->source); })()), "login", [], "any", false, false, false, 34))) {
                // line 35
                echo "  \t";
                if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
                    // line 36
                    echo "  \t\t";
                    if ( !$this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                        // line 37
                        echo "  \t\t<p> Il y a un problème, il semble que vous ne soyez pas sur votre page personnelle. Retournez à votre </p> <a href=\"http://localhost:8000/etudiant/noterEtudiant/";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 37, $this->source); })()), "login", [], "any", false, false, false, 37), "html", null, true);
                        echo "\"> page personnelle </a>
  \t\t";
                    }
                    // line 39
                    echo "  \t";
                }
                // line 40
                echo "  \t
  \t";
            }
            // line 42
            echo "  \t";
        }
        // line 43
        echo "

    
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "etudiant/etudiant.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  235 => 43,  232 => 42,  228 => 40,  225 => 39,  219 => 37,  216 => 36,  213 => 35,  210 => 34,  184 => 31,  177 => 30,  174 => 29,  171 => 28,  164 => 23,  153 => 21,  149 => 20,  144 => 18,  110 => 15,  103 => 14,  101 => 13,  92 => 6,  82 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Information sur l'étudiant {{ etudiant.nomEtudiant }} {{etudiant.prenomEtudiant}}!{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
\t<a href = \"http://localhost:8000/etudiant\"> Retourner sur la page d'accueil </a>
\t{% if is_granted('ROLE_ADMIN') %}
\t <h1> Etudiant {{ etudiant.nomEtudiant }} {{etudiant.prenomEtudiant}} : </h1>
    <p> L'étudiant {{etudiant.nomEtudiant}} {{etudiant.prenomEtudiant}} à passé {{tps}} sur le site du projet Voltaire, il a eu {{resultat.scoreEvaluationInitiale}}% à l'examen initial. Il est donc noté avec le bareme \"{{bareme.nomBareme}}\". Sa note globale s'éleve à {{notetotale}} avec : <br> <ul> <li> {% if noterResultatFinal %} {{pointProgression}} points pour la progression {% endif %} {% if noterResultatFinal == 0 %} {{pointProgression}} points pour la progression , l'étudiant n'a pas encore passé le test final. {% endif %}</li> <li> {{pointNiveau}} points pour le nombre de niveaux acquis avec {{ niveauatteint }} niveaux validés</li> <li> {{pointUtilisation}} points pour le temps passé sur le site. 
    <br><br>
    Voulez vous noter cet étudiant avec un autre barème? 
    <form action=\"http://localhost:8000/etudiant/changerBareme/{{etudiant.login}}\">
  \t\t<select name=\"nomBareme\">
  \t\t\t{% for bareme in allbareme %}
    \t<option value=\"{{bareme.nomBareme}}\">{{bareme.nomBareme}}</option>
    \t{% endfor %}
  \t\t</select>
  \t<br><br>
  \t<input type=\"submit\">
  </form>
  {% endif %}
  {% if is_granted('ROLE_USER') %}
  \t{% if user.Login == etudiant.login %}
  \t<h1> Etudiant {{ etudiant.nomEtudiant }} {{etudiant.prenomEtudiant}} : </h1>
  \t<p> L'étudiant {{etudiant.nomEtudiant}} {{etudiant.prenomEtudiant}} à passé {{tps}} sur le site du projet Voltaire, il a eu {{resultat.scoreEvaluationInitiale}}% à l'examen initial. Il est donc noté avec le bareme \"{{bareme.nomBareme}}\".<br> <ul> <li> {% if noterResultatFinal %} L'Etudiant a effectué le test final {% endif %} {% if noterResultatFinal == 0 %} L'étudiant n'a pas encore passé le test final. {% endif %}</li> <li> L'Etudiant a validé {{ niveauatteint }} niveaux </li> <li> Il a passé {{tps}} sur le site du projet voltaire
  \t<br><br>
  {% endif %}
  {% if user.Login != etudiant.login %}
  \t{% if is_granted('ROLE_USER') %}
  \t\t{% if not is_granted('ROLE_ADMIN') %}
  \t\t<p> Il y a un problème, il semble que vous ne soyez pas sur votre page personnelle. Retournez à votre </p> <a href=\"http://localhost:8000/etudiant/noterEtudiant/{{user.login}}\"> page personnelle </a>
  \t\t{% endif %}
  \t{% endif %}
  \t
  \t{% endif %}
  \t{% endif %}


    
</div>
{% endblock %}
", "etudiant/etudiant.html.twig", "C:\\Users\\Numa mrn\\Desktop\\demoSprint3\\VoltaireQ2Project\\templates\\etudiant\\etudiant.html.twig");
    }
}
