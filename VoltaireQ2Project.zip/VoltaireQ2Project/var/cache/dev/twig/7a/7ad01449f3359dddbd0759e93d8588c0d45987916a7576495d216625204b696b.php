<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* etudiant/index.html.twig */
class __TwigTemplate_ab3b927089c63c1834a933e91438001b16b58f6fa6ecaff9032c0f3027f71880 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "etudiant/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "etudiant/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "etudiant/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello EtudiantController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
    ";
        // line 12
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 13
            echo "    <a href = \"http://localhost:8000/bareme/creerbareme\"> Créer un barème    </a>
    <a href = \"http://localhost:8000/etudiant/uploadCSV\"> Uploader un fichier csv    </a>
    <a href = \"http://localhost:8000/etudiant/generateCSV\"> Exporter les notes    </a>
    ";
        }
        // line 17
        echo "    ";
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 18
            echo "    <a href = \"http://localhost:8000/logout\"> Se déconnecter</a>
    ";
        } else {
            // line 20
            echo "    <a href = \"http://localhost:8000/login\"> Se connecter</a>
    ";
        }
        // line 22
        echo "    <a href = \"http://localhost:8000/etudiant\"> Retourner sur la page d'accueil </a>
    <h1> Bienvenu sur le site du VoltaireQ2Project ! ";
        // line 23
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                echo "  ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 23, $this->source); })()), "login", [], "any", false, false, false, 23), "html", null, true);
                echo " ! </h1> ";
            } else {
                // line 24
                echo "    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["etudiants"]) || array_key_exists("etudiants", $context) ? $context["etudiants"] : (function () { throw new RuntimeError('Variable "etudiants" does not exist.', 24, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["etudiant"]) {
                    // line 25
                    echo "    ";
                    if ((twig_get_attribute($this->env, $this->source, $context["etudiant"], "login", [], "any", false, false, false, 25) == twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 25, $this->source); })()), "login", [], "any", false, false, false, 25))) {
                        // line 26
                        echo "    ";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etudiant"], "nomEtudiant", [], "any", false, false, false, 26), "html", null, true);
                        echo " ";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etudiant"], "prenomEtudiant", [], "any", false, false, false, 26), "html", null, true);
                        echo "</h1>
    ";
                    }
                    // line 28
                    echo "    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['etudiant'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 29
                echo "    ";
            }
            // line 30
            echo "    ";
        }
        // line 31
        echo "
    ";
        // line 32
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 33
            echo "    <p> Voici la liste des étudiants disponibles sur notre base de donnée , il y en a ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["etudiants"]) || array_key_exists("etudiants", $context) ? $context["etudiants"] : (function () { throw new RuntimeError('Variable "etudiants" does not exist.', 33, $this->source); })())), "html", null, true);
            echo " : </p>
    <table>
    \t<tr>
    \t\t<th> Nom Etudiant </th>
    \t\t<th> Prenom Etudiant </th>
    \t\t<th> Identifiant Etudiant </th>
    \t</tr>
    \t";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_sort_filter((isset($context["etudiants"]) || array_key_exists("etudiants", $context) ? $context["etudiants"] : (function () { throw new RuntimeError('Variable "etudiants" does not exist.', 40, $this->source); })())));
            foreach ($context['_seq'] as $context["_key"] => $context["etudiant"]) {
                // line 41
                echo "    \t<tr> <th>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etudiant"], "nomEtudiant", [], "any", false, false, false, 41), "html", null, true);
                echo "</th> <th>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etudiant"], "prenomEtudiant", [], "any", false, false, false, 41), "html", null, true);
                echo "</th> <th> <a href = \"http://localhost:8000/etudiant/noterEtudiant/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etudiant"], "login", [], "any", false, false, false, 41), "html", null, true);
                echo "\" >";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["etudiant"], "login", [], "any", false, false, false, 41), "html", null, true);
                echo " </a></th></tr>
     
 ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['etudiant'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "</table>
";
        } elseif ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
            // line 46
            echo "
    <p> Vous pouvez consulter vos données du projet Voltaire en cliquant ici : </p> <a href=\"http://localhost:8000/etudiant/noterEtudiant/";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 47, $this->source); })()), "login", [], "any", false, false, false, 47), "html", null, true);
            echo "\"> accéder à mes données </a>

";
        } else {
            // line 50
            echo "</h1><p> Vous n'êtes pas connecté ! cliquez ici pour vous connecter : </p> <a href=\"http://localhost:8000/login\"> Se connecter </a>

";
        }
        // line 53
        echo "
    


</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "etudiant/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  207 => 53,  202 => 50,  196 => 47,  193 => 46,  189 => 44,  173 => 41,  169 => 40,  158 => 33,  156 => 32,  153 => 31,  150 => 30,  147 => 29,  141 => 28,  133 => 26,  130 => 25,  125 => 24,  118 => 23,  115 => 22,  111 => 20,  107 => 18,  104 => 17,  98 => 13,  96 => 12,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello EtudiantController!{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<div class=\"example-wrapper\">
    {% if is_granted('ROLE_ADMIN') %}
    <a href = \"http://localhost:8000/bareme/creerbareme\"> Créer un barème    </a>
    <a href = \"http://localhost:8000/etudiant/uploadCSV\"> Uploader un fichier csv    </a>
    <a href = \"http://localhost:8000/etudiant/generateCSV\"> Exporter les notes    </a>
    {% endif %}
    {% if is_granted('IS_AUTHENTICATED_REMEMBERED') %}
    <a href = \"http://localhost:8000/logout\"> Se déconnecter</a>
    {% else %}
    <a href = \"http://localhost:8000/login\"> Se connecter</a>
    {% endif %}
    <a href = \"http://localhost:8000/etudiant\"> Retourner sur la page d'accueil </a>
    <h1> Bienvenu sur le site du VoltaireQ2Project ! {% if is_granted('ROLE_USER') %}{% if is_granted('ROLE_ADMIN') %}  {{user.login}} ! </h1> {% else %}
    {% for etudiant in etudiants %}
    {% if etudiant.login == user.login %}
    {{etudiant.nomEtudiant}} {{etudiant.prenomEtudiant}}</h1>
    {% endif %}
    {% endfor %}
    {% endif %}
    {% endif %}

    {% if is_granted('ROLE_ADMIN') %}
    <p> Voici la liste des étudiants disponibles sur notre base de donnée , il y en a {{etudiants|length}} : </p>
    <table>
    \t<tr>
    \t\t<th> Nom Etudiant </th>
    \t\t<th> Prenom Etudiant </th>
    \t\t<th> Identifiant Etudiant </th>
    \t</tr>
    \t{% for etudiant in etudiants |sort %}
    \t<tr> <th>{{ etudiant.nomEtudiant }}</th> <th>{{ etudiant.prenomEtudiant }}</th> <th> <a href = \"http://localhost:8000/etudiant/noterEtudiant/{{etudiant.login}}\" >{{ etudiant.login }} </a></th></tr>
     
 {% endfor %}
</table>
{% elseif is_granted('ROLE_USER') %}

    <p> Vous pouvez consulter vos données du projet Voltaire en cliquant ici : </p> <a href=\"http://localhost:8000/etudiant/noterEtudiant/{{user.login}}\"> accéder à mes données </a>

{% else %}
</h1><p> Vous n'êtes pas connecté ! cliquez ici pour vous connecter : </p> <a href=\"http://localhost:8000/login\"> Se connecter </a>

{% endif %}

    


</div>
{% endblock %}
", "etudiant/index.html.twig", "C:\\Users\\Numa mrn\\Desktop\\demoSprint3\\VoltaireQ2Project\\templates\\etudiant\\index.html.twig");
    }
}
