<?php 
require_once("../../scr/Controller/EtudiantController.php");
EtudiantController::create();
